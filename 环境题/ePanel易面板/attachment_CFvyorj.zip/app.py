from flask import Flask, send_from_directory
from flask_restx import Api, Resource, fields
import os
from gmssl import sm4

def xor(byte1, byte2):
    result = bytes(x ^ y for x, y in zip(byte1, byte2))
    return result

key = os.urandom(16)
iv = os.urandom(16)
sm4_encryption = sm4.CryptSM4()

app = Flask(__name__,static_url_path="")
api = Api(app, version='1.0', title='ePanel API',doc="/swagger",
    description='一个轻量的云服务器管理面板',
)

ns = api.namespace('api', description='API 接口信息')

userModel = api.model('user', {
    'uid': fields.String(required=True, description='用户ID'),
    'password': fields.String(required=True, description='用户密码')
})

class UserDAO(object):
    def __init__(self):
        self.users = dict[str:str]()

    def getPassword(self, uid)->str:
        if uid not in self.users:
            raise Exception("用户不存在")
        return self.users[uid]
        
    def create(self, uid:str, password:str):
        if uid in self.users:
            raise Exception("用户已注册")
        self.users[uid]=password
        return

DAO = UserDAO()
DAO.create('demoUser','123456')
    
@ns.route('/register')
class Register(Resource):
    @ns.doc('注册')
    @ns.expect(userModel)
    def post(self):
        if 'uid' in api.payload and 'password' in api.payload:
            try:
                DAO.create(api.payload['uid'],api.payload['password'])
            except Exception as e:
                return {'msg': e.args[0]}, 400
            return {'msg': "注册成功"}, 200
        else:
            return {'msg':'用户ID和密码不可为空'}, 400
    
@ns.route('/login')
class Login(Resource):
    @ns.doc('登录')
    @ns.expect(userModel)
    def post(self):
        if 'uid' in api.payload and 'password' in api.payload:
            try:
                password = DAO.getPassword(api.payload['uid'])
                if password != api.payload['password']:
                    raise Exception("用户ID或密码错误")
            except Exception as e:
                return {'msg': "用户ID或密码错误"}, 400
            sm4_encryption.set_key(key, sm4.SM4_ENCRYPT)
            token = sm4_encryption.crypt_cbc(iv, (api.payload['uid'] + ":guest").encode()).hex()
            return {'msg': "登录成功",'token': token}, 200
        else:
            return {'msg':'用户ID和密码不可为空'}, 400

parser = api.parser()
parser.add_argument('Authorization', location='headers')
parser.add_argument('path',location='args')

@ns.route('/file')
@ns.expect(parser)
class ReadFile(Resource):
    @ns.doc('读文件')
    def get(self):
        args = parser.parse_args()
        print(f'请求入参：{args}')
        if 'Authorization' not in args:
            return {'msg':'未登录'}, 400
        if 'path' not in args:
            return {'msg':'路径不可为空'}, 400
        token = args['Authorization']
        try:
            sm4_encryption.set_key(key, sm4.SM4_DECRYPT)
            token_decrypted = sm4_encryption.crypt_cbc(iv, bytes.fromhex(token))
            uid, lv = token_decrypted.split(b":")
        except:
            return {'msg':'token非法'}, 400
        if b"admin" in lv:
            print(args['path'])
            try:
                with open(args['path']) as f:
                    return {'msg': f.read()}, 200
            except:
                return {'msg':"读文件失败"}, 400
        else:
            return {'msg': '非管理员，无权限读取服务器文件'}, 400

@app.errorhandler(404)
def not_found(error):
    return send_from_directory(app.static_folder, 'index.html'), 200

if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0", port=10002)
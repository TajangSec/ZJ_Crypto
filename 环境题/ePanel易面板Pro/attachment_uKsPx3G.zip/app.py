import logging
from flask import Flask, request, send_from_directory, send_file
from flask_restx import Api, Resource, fields
import os
from gmssl import sm3
import time
from datetime import datetime

# token格式:uid:truetoken

def lcg(current_value, a, c, m):
    # 线性同余伪随机数发生器
    return (a * current_value + c) % m

def genToken(lcgCurrent: int)->str:
    currentTokenRaw = str(lcgCurrent)
    token = sm3.sm3_hash(sm3.bytes_to_list(currentTokenRaw.encode()))
    return token

logging.basicConfig(level=logging.INFO)
app = Flask(__name__,static_url_path="")
api = Api(app, version='1.0', title='ePanelPro API',doc="/swagger",
    description='一个轻量的云服务器管理面板',
)
fh = logging.FileHandler("latest.log")
fh.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
app.logger.addHandler(fh)

ns = api.namespace('api', description='API 接口信息')
ns.logger.addHandler(fh)
loginDto = api.model('loginDto', {
    'uid': fields.String(required=True, description='用户ID'),
    'password': fields.String(required=True, description='用户密码'),
    'lcgCurrent': fields.Integer(description='当前LCG值'),
    'lcgA': fields.Integer(description='LCG参数A'),
    'lcgB': fields.Integer(description='LCG参数B'),
    'lcgM': fields.Integer(description='LCG参数M')
})

registerDto = api.model('registerDto', {
    'uid': fields.String(required=True, description='用户ID'),
    'password': fields.String(required=True, description='用户密码'),
})

readonlyDto = api.model('readonly_lockDto', {
    'admin_password': fields.String(required=True, description='管理员密码'),
})

class user:
    uid:str
    password:str
    lcgCurrent:int
    lcgA:int
    lcgB:int
    lcgM:int

class UserDAO(object):
    def __init__(self):
        self.users = dict[str:user]()

    def getPassword(self, uid)->str:
        if uid not in self.users:
            raise Exception("用户不存在")
        return self.users[uid]
        
    def create(self, uid:str, password:str):
        if uid in self.users:
            raise Exception("用户已注册")
        self.users[uid]={uid:uid,password:password}
        return
    
    def setLcgConf(self,uid:str,lcgA,lcgB,lcgM):
        if uid not in self.users:
            raise Exception("用户不存在")
        self.users[uid].lcgA=lcgA
        self.users[uid].lcgB=lcgB
        self.users[uid].lcgM=lcgM
    
    def getLcgConf(self, uid:str)->(int,int,int):
        if uid not in self.users:
            raise Exception("用户不存在")
        return self.users[uid].lcgA,self.users[uid].lcgB,self.users[uid].lcgM

    def getLcgCurrentValue(self, uid:str)->int:
        if uid not in self.users:
            raise Exception("用户不存在")
        return self.users[uid].lcgCurrent
    
    def setLcgCurrentValue(self, uid:str, lcgCurrent:int):
        if uid not in self.users:
            raise Exception("用户不存在")
        self.users[uid].lcgCurrent=lcgCurrent
        return

@ns.route('/register')
class Register(Resource):
    @ns.doc('注册')
    @ns.expect(registerDto)
    def post(self):
        if 'uid' in api.payload and 'password' in api.payload:
            try:
                DAO.create(api.payload['uid'],api.payload['password'])
            except Exception as e:
                return {'msg': e.args[0]}, 400
            return {'msg': "注册成功"}, 200
        else:
            return {'msg':'用户ID和密码不可为空'}, 400

@ns.route('/readonly_lock')
class ReadonlyLock(Resource):
    @ns.doc('开启写保护')
    @ns.expect(readonlyDto)
    def post(self):
        global readonly_lock
        if 'admin_password' in api.payload:
            if api.payload['admin_password'] == admin_password:
                readonly_lock = True
            else:
                return {'msg':'管理员密码错误'}, 400
        else:
            return {'msg': '管理员密码不可为空'}, 400

@ns.route('/readonly_unlock')
class ReadonlyUnlock(Resource):
    @ns.doc('关闭写保护')
    @ns.expect(readonlyDto)
    def post(self):
        global readonly_lock
        if 'admin_password' in api.payload:
            if api.payload['admin_password'] == admin_password:
                readonly_lock = False
            else:
                return {'msg': '管理员密码错误'}, 400
        else:
            return {'msg': '管理员密码不可为空'}, 400

    
@ns.route('/login')
class Login(Resource):
    @ns.doc('登录')
    @ns.expect(loginDto)
    def post(self):
        if 'uid' in api.payload and 'password' in api.payload:
            try:
                password = DAO.getPassword(api.payload['uid'])
                if password != api.payload['password']:
                    raise Exception("用户ID或密码错误")
            except Exception as e:
                return {'msg': "用户ID或密码错误"}, 400
            if 'lcgCurrent' not in api.payload or 'lcgA' not in api.payload or 'lcgB' not in api.payload or 'lcgM' not in api.payload:
                return {'msg': "未提供LCG参数"}, 400
            DAO.setLcgConf(api.payload['uid'],api.payload['lcgA'],api.payload['lcgB'],api.payload['lcgM'])
            DAO.setLcgCurrentValue(api.payload['uid'],api.payload['lcgCurrent'])
            token = api.payload['uid']+':'+genToken(lcgCurrent=api.payload['lcgCurrent']) # 这里生成token是为了让前端自查前端生成token是否正确
            return {'msg': "登录成功",'token': token}, 200
        else:
            return {'msg':'用户ID和密码不可为空'}, 400

parser = api.parser()
parser.add_argument('Authorization', location='headers')
parser.add_argument('path',location='args')

parser_ = api.parser()
parser_.add_argument('Authorization', location='headers')
parser_.add_argument('path',location='body')
parser_.add_argument('content',location='body')

@ns.route('/log')
class Log(Resource):
    @ns.doc('日志')
    def get(self):
        with open('latest.log', 'r') as f:
            log_content = f.read()
        return {"log": log_content}, 200

@ns.route('/read_file')
class ReadFile(Resource):
    @ns.doc('读文件')
    @ns.expect(parser)
    def get(self):
        args = parser.parse_args()
        print(f'请求入参：{args}')
        if 'Authorization' not in args:
            return {'msg':'未登录'}, 400
        if 'path' not in args:
            return {'msg':'路径不可为空'}, 400
        token = args['Authorization']
        uid,token = token.split(":")
        if uid != "admin":
            return {'msg':'非管理员，无权限读取服务器文件'}, 400
        lcgCurrent = DAO.getLcgCurrentValue(uid)
        if token != genToken(lcgCurrent):
            return {'msg':'token非法'},
        try:
            lcgA,lcgB,lcgM =  DAO.getLcgConf(uid)
            DAO.setLcgCurrentValue(uid,lcg(lcgCurrent,lcgA,lcgB,lcgM))
        except:
            return {'msg':'用户不存在'}, 400
        
        try:
            with open(args['path']) as f:
                return {'msg': f.read()}, 200
        except:
            return {'msg':"读文件失败"}, 400

@ns.route('/write_file')
class ReadFile(Resource):
    @ns.doc('写(覆盖模式)文件(若文件不存在则自动创建)')
    @ns.expect(parser)
    def post(self):
        args = parser.parse_args()
        print(f'请求入参：{args}')
        if readonly_lock:
            if 'Authorization' not in args:
                return {'msg': '未登录'}, 400
            if 'path' not in args:
                return {'msg': '路径不可为空'}, 400
            if 'content' not in args:
                return {'msg': '内容不可为空'}, 400
            token = args['Authorization']
            content = args['content']
            uid, token = token.split(":")
            if uid != "admin":
                return {'msg': '非管理员，无权限修改服务器文件'}, 400
            lcgCurrent = DAO.getLcgCurrentValue(uid)
            if token != genToken(lcgCurrent):
                return {'msg': 'token非法'},
            try:
                lcgA, lcgB, lcgM = DAO.getLcgConf(uid)
                DAO.setLcgCurrentValue(uid, lcg(lcgCurrent, lcgA, lcgB, lcgM))
            except:
                return {'msg': '用户不存在'}, 400

            try:
                with open(args['path'], "w") as f:
                    f.write(content)
                    return {'msg': "写文件成功"}, 200
            except:
                return {'msg': "写文件失败"}, 400
        else:
            return {'msg': '写保护中'}, 400

@ns.route('/del_file')
class ReadFile(Resource):
    @ns.doc('删除文件')
    @ns.expect(parser)
    def post(self):
        args = parser.parse_args()
        print(f'请求入参：{args}')
        if readonly_lock:
            if 'Authorization' not in args:
                return {'msg': '未登录'}, 400
            if 'path' not in args:
                return {'msg': '路径不可为空'}, 400
            token = args['Authorization']
            uid, token = token.split(":")
            if uid != "admin":
                return {'msg': '非管理员，无权限删除服务器文件'}, 400
            lcgCurrent = DAO.getLcgCurrentValue(uid)
            if token != genToken(lcgCurrent):
                return {'msg': 'token非法'},
            try:
                lcgA, lcgB, lcgM = DAO.getLcgConf(uid)
                DAO.setLcgCurrentValue(uid, lcg(lcgCurrent, lcgA, lcgB, lcgM))
            except:
                return {'msg': '用户不存在'}, 400

            try:
                os.remove(args['path'])
            except:
                return {'msg': "删除文件失败"}, 400
        else:
            return {'msg': '写保护中'}, 400

@app.before_request
def before():
    ns.logger.info(f'Request: {request.method} {request.url}, Headers: {request.headers.get("Authorization")}')

@app.after_request
def after(response):
    response.direct_passthrough = False
    ns.logger.info(f'Response: {response.data}')
    return response

@app.errorhandler(404)
def not_found(_):
    return send_from_directory(app.static_folder, 'index.html'), 200

if __name__ == '__main__':
    global readonly_lock
    readonly_lock = True
    admin_password = os.urandom(16).hex() # 无法得知管理员密码
    app.run(host='127.0.0.1',port=10003,debug=True)
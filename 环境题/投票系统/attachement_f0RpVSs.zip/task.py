from flask import Flask, request, send_from_directory
from vote_manager import *

app = Flask(__name__, static_url_path="")

url = ""

@app.route(url + '/sign_up', methods=['POST']) # 注册
def sign_up():
    password = request.form.get('password')
    if not password:
        return jsonify({'status': 'error', 'message': "Missing args"})
    else:
        return vote.handle_sign_up(password)

@app.route(url + '/sign_in', methods=['POST']) # 登录
def sign_in():
    uid = request.form.get('uid')
    password = request.form.get('password')
    if not uid or not password:
        return jsonify({'status': 'error', 'message': "Missing args"})
    else:
        return vote.handle_sign_in(uid, password)

@app.route(url + '/sign_out', methods=['POST']) # 登出
def sign_out():
    token = request.form.get('token')
    if not token:
        return jsonify({'status': 'error', 'message': "Missing args"})
    else:
        return vote.handle_sign_out(token)

@app.route(url + '/get_target', methods=['GET']) # 获取所有投票目标及其当前票数
def get_target():
    return vote.handle_get_target()

@app.route(url + '/query_remains', methods=['GET']) # 获取剩余可用票数
def query_remains():
    token = request.args.get('token')
    if not token:
        return jsonify({'status': 'error', 'message': "Missing args"})
    else:
        return vote.handle_query_remains(token)

@app.route(url + '/vote', methods=['POST']) # 投票
def vote():
    target = request.form.get('target')
    token = request.form.get('token')  # 要求提供token, 以验证身份
    if not target or not token:
        return jsonify({'status': 'error', 'message': "Missing args"})
    else:
        return vote.handle_vote(target, token)

@app.errorhandler(404)
def not_found(_):
    return send_from_directory(app.static_folder, 'index.html'), 200

if __name__ == '__main__':
    vote = VoteManage()
    app.run(host='0.0.0.0', port=1337)

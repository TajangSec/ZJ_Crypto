import os, random, json
from flask import jsonify
from gmssl import sm4


class VoteManage:
    def __init__(self):
        self.sm4_instance = sm4.CryptSM4()
        self.user_dict = {}
        self.key = os.urandom(16)
        self.iv = os.urandom(16)
        self.vote_target = {
            "候选人A": 0,
            "候选人B": 0,
            "flag": 0
        }
        # 模拟真实环境
        self.uid_base = random.randint(10000000, 99999999)
        for _ in range(random.randint(15, 25)):
            self.uid_base += random.randint(0, 100)
            self.user_dict[str(self.uid_base)] = {"password": os.urandom(8).hex(), "remain": 9, "first_sign_in": False}
            self.vote_target[random.choice(list(self.vote_target))] += 1
        # 只能注册一次
        self.has_sign_up = False

    def get_uid_from_token(self, token):
        self.sm4_instance.set_key(self.key, sm4.SM4_DECRYPT)
        token_dec = self.sm4_instance.crypt_cbc(self.iv, bytes.fromhex(token))
        token_dec_list = token_dec.split(b":")
        if len(token_dec_list) > 1:
            try:
                return token_dec_list[-1].decode()
            except UnicodeDecodeError:
                return None

    def handle_query_remains(self, token):
        uid = self.get_uid_from_token(token)
        if uid:
            if uid in self.user_dict:
                return jsonify({'status': 'success', 'message': self.user_dict[uid]["remain"]})
            else:
                return jsonify({'status': 'error', 'message': '您未注册'})
        else:
            return jsonify({'status': 'error', 'message': 'token非法'})

    def handle_get_target(self):
        return jsonify({'status': 'success', 'message': json.dumps(self.vote_target)})

    def handle_sign_up(self, password):
        if self.has_sign_up:
            return jsonify({'status': 'error', 'message': '每个用户只能注册一次'})
        else:
            self.has_sign_up = True
            self.uid_base = self.uid_base + random.randint(0, 100)
            uid = str(self.uid_base)
            self.user_dict[uid] = {"password": password, "remain": 10, "first_sign_in": True}
            return jsonify({'status': 'success', 'message': uid})

    def handle_sign_in(self, uid, password):
        if uid in self.user_dict:
            if password == self.user_dict[uid]["password"]:
                self.sm4_instance.set_key(self.key, sm4.SM4_ENCRYPT)
                token = self.sm4_instance.crypt_cbc(self.iv, os.urandom(16) + b":" + uid.encode()).hex()
                if self.user_dict[uid]["first_sign_in"]:
                    self.user_dict[uid]["first_sign_in"] = False
                    return jsonify({'status': 'success', 'message': '欢迎新用户: {}'.format(uid), 'token': token})
                else:
                    return jsonify({'status': 'success', 'message': '欢迎回来: {}'.format(uid), 'token': token})
            else:
                return jsonify({'status': 'error', 'message': '密码错误'})
        else:
            return jsonify({'status': 'error', 'message': '您未注册'})

    def handle_sign_out(self, token):
        uid = self.get_uid_from_token(token)
        if uid:
            if uid in self.user_dict:
                jsonify({'status': 'success', 'message': '登出成功'})
            else:
                return jsonify({'status': 'error', 'message': '您未注册'})
        else:
            return jsonify({'status': 'error', 'message': 'token非法'})

    def handle_vote(self, target, token):
        uid = self.get_uid_from_token(token)
        if uid:
            if uid in self.user_dict:
                if target in self.vote_target:
                    if self.user_dict[uid]["remain"] > 0:
                        is_valid = True
                    else:
                        return jsonify({'status': 'error', 'message': '剩余票数不足'})
                else:
                    return jsonify({'status': 'error', 'message': '没有这个候选人'})
                # 判断参数是否合法(例如投票目标是否合法, 剩余票数是否不足)
                if is_valid:
                    self.user_dict[uid]["remain"] -= 1
                    self.vote_target[target] += 1
                    # 执行投票
                    if self.vote_target[target] >= 100 and target == "flag":
                        with open("flag.txt") as file:
                            flag = file.read()
                            return jsonify({'status': 'success', 'message': flag})
                    else:
                        return jsonify({'status': 'success', 'message': '投票成功'})
            else:
                return jsonify({'status': 'error', 'message': '您未注册'})
        else:
            return jsonify({'status': 'error', 'message': 'token非法'})

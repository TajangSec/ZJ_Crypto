import json, pickle
import os
from flask import jsonify
from gmssl import sm4


class TicketInfo:
    def __init__(self, uid, name, tel, ticket_info):
        self.uid = uid
        self.name = name
        self.tel = tel
        self.ticket_info = ticket_info


def handle_query_all_tickets():
    with open("tickets_info.json", "r") as file:
        tickets_dict = file.read()
        return jsonify({'status': 'success', 'message': tickets_dict})

class TicketsManage:
    def __init__(self):
        self.sm4_instance = sm4.CryptSM4()
        self.user_dict = {}
        self.online_user = {}
        # 模拟真实环境
        tickets_dict = {
            "XX演唱会": {"price": 100, "time": "x年x月x日x时x分", "location": "xx省xx市xx区xx路xx号", "remain": 10},
            "XX展览会": {"price": 100, "time": "x年x月x日x时x分", "location": "xx省xx市xx区xx路xx号", "remain": 0},
            "flag": {"price": 10000, "time": "x年x月x日x时x分", "location": "xx省xx市xx区xx路xx号", "remain": 1}
        }
        with open("tickets_info.json", "w") as file:
            file.write(json.dumps(tickets_dict))

    def handle_sign_up(self, uid, password, key):
        if uid in self.user_dict:
            return jsonify({'status': 'error', 'message': '您已注册'})
        else:
            self.user_dict[uid] = {"password": password, "tickets": [], "score": 0, "first_sign_in": True, "key": key}
            return jsonify({'status': 'success', 'message': '注册成功'})

    def handle_sign_in(self, uid, password):
        if uid in self.user_dict:
            if password == self.user_dict[uid]["password"]:
                token = os.urandom(16).hex() # 用于验证身份的token
                self.online_user[uid] = token
                if self.user_dict[uid]["first_sign_in"]:
                    self.user_dict[uid]["first_sign_in"] = False
                    self.user_dict[uid]["score"] = 100
                    return jsonify({'status': 'success', 'message': '欢迎新用户: {}'.format(uid), 'token': token})
                else:
                    return jsonify({'status': 'success', 'message': '欢迎回来: {}'.format(uid), 'token': token})
            else:
                return jsonify({'status': 'error', 'message': '密码错误'})
        else:
            return jsonify({'status': 'error', 'message': '您未注册'})

    def handle_view_tickets(self, uid, token):
        if uid in self.user_dict:
            if uid in self.online_user:
                if token == self.online_user[uid]:
                    return jsonify({'status': 'success', 'message': json.dumps(self.user_dict[uid]["tickets"])})
                else:
                    return jsonify({'status': 'error', 'message': 'token非法'})
            else:
                return jsonify({'status': 'error', 'message': '请先登录'})
        else:
            return jsonify({'status': 'error', 'message': '您未注册'})

    def query_score(self, uid, token):
        if uid in self.user_dict:
            if uid in self.online_user:
                if token == self.online_user[uid]:
                    return jsonify({'status': 'success', 'message': str(self.user_dict[uid]["score"])})
                else:
                    return jsonify({'status': 'error', 'message': 'token非法'})
            else:
                return jsonify({'status': 'error', 'message': '请先登录'})
        else:
            return jsonify({'status': 'error', 'message': '您未注册'})

    def handle_buy_tickets(self, uid, ticket, number, tel, name, token):
        if uid in self.user_dict:
            if uid in self.online_user:
                if token == self.online_user[uid]:
                    with open("tickets_info.json", "r") as file:
                        tickets_dict = json.loads(file.read())
                    if ticket in tickets_dict:
                        if self.user_dict[uid]["score"] >= tickets_dict[ticket]["price"] * number:
                            if number > 0:
                                if tickets_dict[ticket]["remain"] > 0:
                                    is_valid = True
                                else:
                                    return jsonify({'status': 'error', 'message': '该票已售罄'})
                            else:
                                return jsonify({'status': 'error', 'message': '只能购买正数张票'})
                        else:
                            return jsonify({'status': 'error', 'message': '积分不足'})
                    else:
                        return jsonify({'status': 'error', 'message': '没有这种票'})
                    # 判断参数是否合法(例如是否为购买负数张, 积分是否不足)
                    if is_valid:
                        ticket_info = {
                            "name": ticket,
                            "number": number,
                            "time": tickets_dict[ticket]["time"],
                            "location": tickets_dict[ticket]["location"],
                            "price": tickets_dict[ticket]["price"]
                        }
                        # 执行交易
                        self.user_dict[uid]["score"] -= tickets_dict[ticket]["price"] * number
                        tickets_dict[ticket]["remain"] -= 1
                        self.user_dict[uid]["tickets"].append(ticket_info)
                        # 生成电子票据并返回给客户端, 要求其保存该票据
                        bill = pickle.dumps(TicketInfo(uid, name, tel, ticket_info))
                        self.sm4_instance.set_key(self.user_dict[uid]["key"].encode(), sm4.SM4_ENCRYPT)
                        return jsonify({'status': 'success', 'message': self.sm4_instance.crypt_ecb(bill).hex()})
                else:
                    return jsonify({'status': 'error', 'message': 'token非法'})
            else:
                return jsonify({'status': 'error', 'message': '请先登录'})
        else:
            return jsonify({'status': 'error', 'message': '您未注册'})

    def handle_check_tickets(self, uid, bill, key, token):
        if uid in self.user_dict:
            if uid in self.online_user:
                if token == self.online_user[uid]:
                    self.sm4_instance.set_key(key.encode(), sm4.SM4_DECRYPT)
                    try:
                        bill_dec = self.sm4_instance.crypt_ecb(bytes.fromhex(bill))
                        bill_info = pickle.loads(bill_dec)
                    except ValueError:
                        return jsonify({'status': 'error', 'message': '密钥或票据非法'})
                    except pickle.UnpicklingError:
                        return jsonify({'status': 'error', 'message': '密钥或票据非法'})
                    else:
                        if bill_info.uid == uid:
                            # 验票成功
                            self.user_dict[uid]["tickets"].remove(bill_info.ticket_info)
                            msg = {
                                "uid": uid,
                                "name": bill_info.name,
                                "tel": bill_info.tel,
                                "ticket_info": bill_info.ticket_info
                            }
                            if bill_info.ticket_info["name"] == "flag":
                                with open("flag.txt") as file:
                                    flag = file.read()
                                    return jsonify({'status': 'success', 'message': flag})
                            else:
                                return jsonify({'status': 'success', 'message': json.dumps(msg)})
                        else:
                            return jsonify({'status': 'error', 'message': '您不是该票的购票者'})
                else:
                    return jsonify({'status': 'error', 'message': 'token非法'})
            else:
                return jsonify({'status': 'error', 'message': '请先登录'})
        else:
            return jsonify({'status': 'error', 'message': '您未注册'})
